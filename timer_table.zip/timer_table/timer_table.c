#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {

	// Note multuplier
	double fmul = pow(2.0, 1.0 / 12.0);

	// The standard A is 220 Hz
	double a0 = 220.0;

	// Handy tables to print
	char* notes[] = { "C", "CIS", "D", "DIS", "E", "F", "FIS", "G", "GIS", "A", "AIS", "B"};
	char *spaces[] = { "  ","", "  ", "", "  ", "  ", "", "  ", "", "  ", "", "  " };

	// System frequency
	double fsys = 84000000;

	if (argc >= 2) {
		fsys = strtod(argv[1], NULL);
		if (fsys <= 0.0) {
			printf("Frequency must be > 0.0\n");
			return 0;
		}
	}

	if (argc >= 3) {
		a0 = strtod(argv[2], NULL);
		if (fsys <= 0.0) {
			printf("Standard tone must be > 0.0\n");
			return 0;
		}
	}

	// The standard C is +/- 131 Hz
	double c0 = a0 / pow(fmul, 9);

	// Auto calculation of prescaler
	double prescaler = (double)((int)(fsys / c0 / 65536 / 2) + 1.0);

	int i, j;

	double note = c0;

	printf("// Musical notes table generator v1.0\n");
	printf("// Table for 16-bit timer register @ %.4f MHz\n\n", fsys / 1000000);
	printf("#define STD_TONE %f\n", a0*2);
	printf("#define FREQ_APB1 %d\n", (int)fsys);
	printf("#define PRESCALER %.0f\n", prescaler);
	for (j = 0; j < 5; j++) {
		for (i = 0; i < 12; i++) {
			int timer = (int)(fsys / prescaler / note / 2 + 0.5)-1;
			printf("#define %s%d%s   %5d   // %.2f Hz\n", notes[i], j, spaces[i], timer, note);
			note = note * fmul;
		}
	}

	printf("#define H       1      // Herhaal/repeat\n");
	printf("#define R       2      // Rust/rest\n");
	printf("#define S       3      // Stop\n");

	return 0;
}